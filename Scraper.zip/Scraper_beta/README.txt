(version 1.0)

SEHA was garbage, but we've made something better...


Welcome to Scraper.
  Python 3.9 or later is required to run Scraper.
                           Download python at: https://www.python.org


                                                                             Requirements
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
OS: Windows 10/8/8.1 with Python 3.9 or later
RAM: 2GB or more
PROCESSOR: Core i3 or better

                                                                         Information (IMPORTANT)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------

This is the first release of Scraper so it may be buggy or you may recieve errors, or it may not run at all!
Please run this in a virtual machine, this will not damage your main machine, and if it does i am not responsible.
If you do run into bugs please contact me about it so i can fix it.

Contact me at: babylard1@protonmail.com



Malware made with Python 3.9 and Visual Studio Code